#ifndef LTL2BA_LEX_DEF
#define LTL2BA_LEX_DEF

#include <ltsmin-lib/ltsmin-buchi.h>

extern void ltsmin_ltl2ba(ltsmin_expr_t);
extern ltsmin_buchi_t *ltsmin_buchi();

#endif // LTL2BA_LEX_DEF
