// -*- tab-width:4 ; indent-tabs-mode:nil -*-

#ifndef LTS_PG_IO_H
#define LTS_PG_IO_H

#include <lts-lib/lts.h>


extern void lts_write_pg(const char*name, lts_t lts);

#endif // LTS_PG_IO_H
