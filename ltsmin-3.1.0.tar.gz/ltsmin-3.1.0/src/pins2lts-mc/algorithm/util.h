
#ifndef AUTIL_H
#define AUTIL_H

ref_t          *get_parent_ref (wctx_t *ctx, ref_t ref);

#endif //
